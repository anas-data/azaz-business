import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';

let proc: ReturnType<typeof spawn>;
test.before(async () => {
  proc = spawn(process.execPath, ['--experimental-strip-types', 'apps/api/src/server.ts'], { stdio: 'ignore' });
  await new Promise(r => setTimeout(r, 350));
});
test.after(() => proc.kill());

test('health endpoint works', async () => { const r = await fetch('http://127.0.0.1:8080/health'); assert.equal(r.status, 200); const j = await r.json(); assert.equal(j.status, 'ok'); });

test('tenant-scoped product creation and idempotent sale', async () => {
  const h = { authorization: 'Bearer test', 'x-organization-id': 'org-a', 'content-type': 'application/json' };
  const p = await fetch('http://127.0.0.1:8080/api/v1/products', { method:'POST', headers:h, body:JSON.stringify({name:'Test Product', sku:'T-1'}) });
  assert.equal(p.status, 201); const product = await p.json();
  const s1 = await fetch('http://127.0.0.1:8080/api/v1/sales', { method:'POST', headers:{...h, 'idempotency-key':'k1'}, body:JSON.stringify({productId:product.id, quantity:2, unitPrice:5}) });
  const s2 = await fetch('http://127.0.0.1:8080/api/v1/sales', { method:'POST', headers:{...h, 'idempotency-key':'k1'}, body:JSON.stringify({productId:product.id, quantity:999, unitPrice:999}) });
  assert.equal(s1.status, 201); assert.equal(s2.status, 200); assert.deepEqual((await s1.json()).id, (await s2.json()).id);
  const other = await fetch('http://127.0.0.1:8080/api/v1/products', {headers:{authorization:'Bearer test','x-organization-id':'org-b'}}); assert.equal((await other.json()).length, 0);
});
